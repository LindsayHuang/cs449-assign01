import java.util.LinkedList;
/*
 * This class represents an user in the key system. Each user has an username
 * and a keyList. username is a string, and keyList is an Integer linkedList. The username must
 * comprise of lowercase alphabets, and the length of username should between 1 and 8.
 * KeyList presents a list of key numbers(Integer) assigned to this user.
 * The initial value of keyList should be an empty list.
 * 
 * @author Wanqian(Lindsay) Huang
 * created on Sep 07, 2018
 */
public class User {
	private String username;
	private LinkedList<Integer> keyList;
	
	/**
	 * The following is a constructor for this class. It accepts one String and one Integer LinkedList
	 * as parameters and assigns the values for the two state variables. The constructor throws an exception
	 * if the username or keyList is not in proper format as explained in the comment at the beginning of 
	 * this class.
	 * @param usr: the username to be assigned.
	 * @param keys: the keyList to be assigned. The initial value of keyList should be an empty LinkedList.
	 * @throws Exception: when username or keyList is not in proper format throw a exception.
	 */
	public User(String usr,LinkedList<Integer> keys) throws Exception {
		// Check for the correct length of username. Length of username should between 1 and 8.
		if(usr.length() > 8 || usr.length()<1) {
			throw new InvalidDataException ("User",
	                "User", "the length of username needs to between 1 and 8");
		}
		// i is the index for each character of username string.
        int i = 0;
        // check for valid characters in username
        while (i < usr.length()) {
            if (usr.charAt(i) < 97 || usr.charAt(i) > 122) {
	    			throw new InvalidDataException ("User",
	    	                "User", "username must comprise of lowercase alphabets");
            }
            i++;
        }
        // keyList must be empty when a user is just created.
        if(keys.size() != 0) {
			throw new InvalidDataException ("User",
	                "User", "the initial value of keyList should be an empty LinkedList.");
        }
        // Store username and keyList as a part of an user record.
        username = usr;
        keyList = keys;
	}
	
	/**
	 * The following method allows to get the username of the user.
	 * @return the username of this user.
	 */
	public String getUserName() {
		return username;
	}
	
	/**
	 * The following method allows to get a list of key numbers which are assigned to this user.
	 * @return the key list belonged to this user.
	 */
	public LinkedList<Integer> getKeyList(){
		return keyList;
	}
	
	/**
	 * The following method allows to assign a new key to this user.
	 * @param keyNumber: the new key which is assigned to this user.
	 */
	public void addKey(int keyNumber) throws Exception{
		// Key number must between 1 to 200. Key number is unique. 
		if(keyNumber >200 || keyNumber <=0 ) {
			throw new InvalidDataException ("User",
	                "addKey", "keyNumber must between 1 and 200");
		}
		// Add new key to this user's keyList.
		keyList.add(keyNumber);
	}
	
	/**
	 * The following method allows to remove a key from this user.
	 * @param keyNumber: the key which is going to be removed from this user.
	 */
	public void removeKey(int keyNumber) throws Exception{
		// Check the user has this key.
		if(!keyList.contains(keyNumber)) {
			throw new InvalidDataException ("User",
	                "removeKey", "this user doesn't have this key");
		}
		keyList.removeFirstOccurrence(keyNumber);
	}
}
