import java.util.LinkedList;
/*
 * This class represents a lock in the key system. Each lock has a lockNumber
 * and a keyList. lockNumber is an unique integer number, and keyList is an Integer linkedList. The lock number
 * must be an integer number between 1 and 100. keyList presents a list of key numbers(Integer) assigned to this lock.
 * The initial value of keyList should contain one key number(between 1 and 200).
 * 
 * @author Wanqian(Lindsay) Huang
 * created on Sep 07, 2018
 */
public class Lock {
	private int lockNumber;  
	private LinkedList<Integer> keyList;
	
	/**
	 * The following is a constructor for this class. It accepts one integer number and
	 * a linkedList<Integer> as parameters and assigns the values for the two state variables.
	 * The constructor throws an exception if the keyNumber or keyList is not in proper format
	 * or reasonable value as explained in the comment at the beginning of this class. 
	 * @param lockNum: the lock number to be assigned to this lock.
	 * @param keys: the keyList to be assigned to this lock.
	 * @throws Exception: when lockNum or keyList is not in proper format or value throw a exception.
	 */
	public Lock(int lockNum,LinkedList<Integer> keys) throws Exception {
		// Check for the correct number for the lock. Lock number need to be unique and between 1 and 100.
		if(lockNum > 100 || lockNum<1) {
			throw new InvalidDataException ("Lock",
	                "Lock", "lock number needs to be an integer number between 1 and 100");
		}

        // The initial keyList of lock needs to have one key Number
        if(keys.size() != 1) {
        		throw new InvalidDataException ("Lock",
	                "Lock", "The initial keyList of lock needs to have one key Number");
        }
        
        // After make sure the keyList of lock contains one key number, assign the key number to firstKey.
        int firstKey = keys.get(0);
        
        // Key number must between 1 and 200.
        if(firstKey>200 || firstKey <= 0) {
			throw new InvalidDataException ("Lock",
	                "Lock", "key number needs to be an integer number between 1 and 200");
        }
        // Store lockNumber and keyList as a part of a lock record.
        lockNumber = lockNum;
        keyList = keys;
	}
	
	/**
	 * The following method allows to get the lockNumber of the lock.
	 * @return the lockNumber of the lock.
	 */
	public int getLockNum() {
		return lockNumber;
	}
	
	/**
	 * The following method allows to get a list of keys' number which assigned to this lock.
	 * @return the keyList of this lock
	 */
	public LinkedList<Integer> getKeyList(){
		return keyList;
	}
	
	/**
	 * The following method accepts a key number. Key number is an integer. 
	 * This method allows to add a keyNumber to this lock.
	 * @param keyNumber: a new key's number which is assigned to this lock
	 */
	public void addKey(int keyNumber) throws Exception{
		// Key number must between 1 to 200. Key number is unique. 
		if(keyNumber >200 || keyNumber <=0 ) {
    			throw new InvalidDataException ("Lock",
	                "addKey", "The entered key number needs to be a integer number between 1 and 200");
		}
		// Add the new key to the lock's keyList 
		keyList.add(keyNumber);
	}
}