import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
/*
 * This class represents an key system. This key system contains some functionalities.
 * This system contains variable keyList, userList, lockList and exitFlag. keyList is an key ArrayList
 * which stores all keys created in this system. userList is an user ArrayList which stores all user entered
 * into this system. lockList is an lock ArrayList which stores all lock created in this system.
 * exitFlag is a boolean value. When the user enter an "exist" command, the value of exitFlag will be true. This
 * system will end. 
 * 
 * @author Wanqian(Lindsay) Huang
 * created on Sep 07, 2018
 */
public class MainKeySystem {

	private static ArrayList<Key> keyList = new ArrayList<Key>();
	private static ArrayList<User> userList = new ArrayList<User>();
	private static ArrayList<Lock> lockList = new ArrayList<Lock>();
	private static Boolean  exitFlag = false;
	
	/**
	 * Execute this key system. When user enter "exit" command, this system will end.
	 * @param args: the entered arguments of this system.
	 * @throws Exception: throw exceptions if they are found.
	 */
	public static void main(String[] args) throws Exception {
		// create a scanner to scan the enter information(command/username/keynumber/locknumber/...)
		Scanner scanner = new Scanner(System.in);
		// Print commands will print commands and ask a user to choose a command from 1 to 9.
		printCommands(scanner);
		// Get the command user entered. 
		String command = scanner.nextLine();
		// This system will keeping working until user enter an "exit" command.
		while(!exitFlag) {
			// Check for the correct number of command. Keeping asking until user enters a command between 1 and 9.
			while(!validateCommand(command)) {
				System.out.println("Please type a number from 1 to 9: ");
				// When the last command is invalid, get the next command user entered. 
				command = scanner.nextLine();
			}
			// Execute commands.
			manageCommand(command,scanner);  
			// After user finished one command, asking user to start another command to exit this system.
			System.out.println("Please enter another command or \"exit\":");
			command = scanner.nextLine();
			// User chooses to exit.
			if(command.equals("exit")) {
				System.out.println("See you!");
				break;
			}
		}  
		// Close scanner.
		scanner.close();
	}
	
	/**
	 * The following method accepts a command and a scanner as arguments.
	 * command is a string user entered. scanner is an scanner helps this 
	 * system to scanner for entered information. 
	 * This method will execute the functionalities which are chosen by user.
	 * @param command: a command that user wants to execute.
	 * @param scanner: a scanner helps to scanner entered information. 
	 * @throws Exception: throw exceptions if they are found.
	 */
	private static void manageCommand(String command,Scanner scanner) throws Exception {
		// Add a new user to this system.
		if(command.equals("1")) {
			createUser(scanner);
		}
		// Add a new lock to this system. Then add a new key, and assign it to this new lock.
		else if(command.equals("2")) {
			createLock(scanner);
		}
		// Add a new key to an existing lock.
		else if(command.equals("3")) {
			createKeyToLock(scanner);
		}
		// Assign a key to an existing lock.
		else if(command.equals("4")) {
			assignKeyToLock(scanner);
		}
		// Assign a key to a user.
		else if(command.equals("5")) {
			assignKeyToUser(scanner);
		}
		// Take away a key from a user.
		else if(command.equals("6")) {
			removeKeyFromUser(scanner);
		}
		// Display all keys; for each key, display all the locks it opens.
		else if(command.equals("7")) {
			displayAllKeys(); 
		}
		// Display all locks; for each lock, display all the keys opening this lock.
		else if(command.equals("8")) {
			displayAllLocks(); //Display empty array.
		}
		// Display all the keys assigned to a given user.
		else if(command.equals("9")) {
			displayUserKey(scanner); //Display empty array.
		}
	}
	
	/**
	 * The following method accepts a scanner as arguments. This scanner will scanner entered information.
	 * This method will display all the keys assignegd to a given user.
	 * @param scanner: a scanner helps to scanner entered information. 
     * @throws Exception: throw exceptions if they are found.
	 */
	private static void displayUserKey(Scanner scanner) throws Exception{
		// existingUserList is a list of all username in this system. 
		// If there is no user in this system, existingUserList will be an empty string.
		String existingUserList = getAllUserNames();
		// If there is no user in this system. Print a message and exit this method.
		if(existingUserList.length() == 0) {
			System.out.println("There is no user entered.");
			return;
		}
		// Print all username in this system, and ask user to choose an username.
		System.out.println("Please enter a username you want to search from ( "+getAllUserNames()+"):");
		// Get the username that user enters. 
		String username = scanner.nextLine();
		// Check for the correct format of username and check if this username is existing in this system.
		// if the format of username is wrong or this username is not existing in this system, asking user to enter another username.
		while(!existUserName(username) || !validateUserName(username)) {
			System.out.println(username+" is not found." );
			System.out.print("Here are exsit usernames ( "+getAllUserNames()+")");
			System.out.println("\nPlease enter a exist username:" );
			// User enters another username.
			username = scanner.nextLine();
		}
		// Find user object by username.
		User usr = getUserByUsername(username);
		// Print username and a list of key which are assigned to this user.
		System.out.println("Username "+username+" has key(s): "+usr.getKeyList().toString());

	}
	
	/**
	 * Display all keys; for each key, display all the locks it opens.
	 */
	private static void displayAllKeys() {
		// Check the number of all keys in this system. If this system doesn't have any key, printing a message and exiting this method directly.
		if(getAllKeyNumbers().length() == 0) {
			System.out.println("There is no key entered.");
			return;
		}
		// Display all keys, and display all the locks it opens.
		keyList.forEach((k)->{
			System.out.println("Key "+k.getKeyNumber()+" opens lock: "+getLocksByKey(k.getKeyNumber()).toString());
		});
	}
	
	/**
	 * The following method accepts one keyNum as argument. 
	 * Get all lock numbers associated with this key number
	 * @param keyNum: the key number which is used to find associated lock numbers.
	 * @return lockListForAKey is an integer linkedList contains a list of lock numbers which are associated with the entered key number.
	 */
	private static LinkedList<Integer> getLocksByKey(int keyNum) {
		// Create an empty lock list first.
		LinkedList<Integer> lockListForAKey = new LinkedList<Integer>();
		// Check each lock in this system.
		lockList.forEach((l)->{
			// if a lock's keylist contains this keyNum, add this lock number to lockListForAKey.
			if(l.getKeyList().contains(keyNum)) {
				lockListForAKey.add(l.getLockNum());
			}
		});
		return lockListForAKey;
	}
	
	/**
	 * The following method is to display all locks; for each lock, display all the keys opening this lock.
	 * @throws Exception throw exception when it has error.
	 */
	private static void displayAllLocks() throws Exception{
		// If the number of lock in this system is 0. Print a message, and exit this method.
		if(getAllLockNumbers().length() == 0) {
			System.out.println("There is no lock entered.");
			return;
		}
		// Loop through each lock in this system.
		lockList.forEach((l)->{
			// Print each lock number and all key numbers which are assigned to this lock.
			System.out.println("Lock "+l.getLockNum()+" can be opened by key(s): "+l.getKeyList().toString());
		});
	}
	
	/**
	 * The following method accept a scanner. This scanner will scanner entered information.
	 * This method is to take away a key from a user.
	 * @param scanner: a scanner helps to scanner more entered information. 
	 * @throws Exception: throw exceptions if it's found.
	 */
	private static void removeKeyFromUser(Scanner scanner) throws Exception{
		
		// Check the number of user in this system. If there is no user in this system, print a message and exit this method.
		if(getAllUserNames().length() == 0) {
			System.out.println("There is no user in this system. Please enter some username first.");
		}
		// Print all username in this system. 
		System.out.println("Please choose a user ( "+getAllUserNames()+")");
		String user= scanner.nextLine();
		while(!validateUserName(user) || !existUserName(user)) {
			System.out.println("Please choose a existing username from "+getAllUserNames());
			user = scanner.nextLine();
		}
		// Get the existing user object by the username.
		User existUserObj = getUserByUsername(user);
		// Print username, and all key numbers which are assigned to this user.
		System.out.println(user+" has key(s) "+existUserObj.getKeyList().toString());
		// Ask user to enter a key number or exit this method
		System.out.println("Please choose a key number you want to remove or type \"back\" to choose another command: ");
		String keyNum = scanner.nextLine();
		// user choose to exit this method.
		if(keyNum.equals("back")) {
			return;
		}
		// a flag for key number. keyNumFlag will true when keyNum is valid, is existing in this system, and belong to selected user.
		boolean keyNumFlag = false;
		// Loop until a proper key num is found.
		while(!keyNumFlag) {
			// Check the format of key number, and check whether this keyNumber is exist in this system or not.
			while(!validateKeyNum(keyNum) || !existKeyNum(keyNum)) {
				// if the format of key number is wrong, print an error message.
				if(!validateKeyNum(keyNum)) {
					System.out.println("Please type a valid key number or type \"back\" to choose another command: ");
				}
				// if this key number is not exist in this system, print an error message.
				else if(!existKeyNum(keyNum)) {
					// Ask user to enter another key number or exit this method
					System.out.println("This key has not been created. Please enter a used key number or type \"back\" to choose another command: ");
				}		
				keyNum = scanner.nextLine();
				// user choose to exit this method.
				if(keyNum.equals("back")) {
					return;
				}
				// Check whether user has this key or not. 
				if(!keyMatchUser(Integer.parseInt(keyNum),existUserObj)) {
					// Ask user to re-enter an key number or exit this method.
					System.out.println("Key "+keyNum+" is not assigned to user "+user+". Please choose another key number or type \"back\" to choose another command:");
					keyNum = scanner.nextLine();
					// user choose to exit this method.
					if(keyNum.equals("back")) {
						return;
					}
				}
			}			
			// Check whether user has this key or not. 
			if(!keyMatchUser(Integer.parseInt(keyNum),existUserObj)) {
				// Ask user to re-enter an key number or exit this method.
				System.out.println("Key "+keyNum+" is not assigned to user "+user+". Please choose another key number or type \"back\" to choose another command:");
				keyNum = scanner.nextLine();
				// user choose to exit this method.
				if(keyNum.equals("back")) {
					return;
				}
			}else {
				keyNumFlag = true;
			}
		}
		// Remove the key from this user.
		existUserObj.removeKey(Integer.parseInt(keyNum));
		// Get key object by key number.
		Key removedKey = getKeyByKeyNum(Integer.parseInt(keyNum));
		// Change the status of the key to be false(unassigned to any user).
		removedKey.changeStatus();
		// since a user object is updated, Update the userlist in this system.
		updateUserList(existUserObj);
		// since a key object is updated, update the keyList in this system.
		updateKeyList(removedKey);
		// Print a success message.
		System.out.println("Key "+Integer.parseInt(keyNum)+" is removed from User "+user);
	}
	
	/**
	 * This method check whether this system has a key which is not assigned to any one.
	 * @return hasAvailabe: return true if there is a key is not assigned to any user in this system. 
	 */
	private static boolean hasAvailableKeys() {
		boolean hasAvailable = false;
		// Loop through each key object of keyList in this system.
		for(Key key:keyList) {
			if(!key.getStatus()) {
				// There is a key is not assigned to any user.
				hasAvailable = true;
				break;
			}
		}
		return hasAvailable;
	}
	
	/**
	 * This method is to assign a key to a user.
	 * @param scanner: a scanner helps to scanner more entered information. 
	 * @throws Exception: throw exceptions if it's found.
	 */
	private static void assignKeyToUser(Scanner scanner) throws Exception{
		// One key can only belong to one user. If all keys are assigned to someone, printing a message and exit this method.
		if(!hasAvailableKeys()) {
			System.out.println("There is no available key now. Please create some new keys or remove some keys from users");
		}
		// Printing all username in this system.
		System.out.println("Please choose a user ( "+getAllUserNames()+")");
		// Get the username which is entered. 
		String user= scanner.nextLine();
		// Check the format of username, and check whether this username is exist in this system or not.
		while(!validateUserName(user) || !existUserName(user)) {
			System.out.println("Please choose a existing/valid username from "+getAllUserNames());
			user = scanner.nextLine();
		}
		// Get the existing user object by username.
		User existUserObj = getUserByUsername(user);
	    // Print all key number in this system.	
		System.out.println("Please choose a key number ( "+getAllKeyNumbers()+")");
		// Get the key number which is entered.
		String keyNum = scanner.nextLine();
		// keyFlag will be true until a key is selected in the end. 
		boolean keyAssignedFlag = true;
		// Check the status of the entered key. If the key is assigned to another user, asking to enter another key number.
		while(keyAssignedFlag) {
			// Check the format of key number, and check whether this key number is exist in this system or not.
			while(!validateKeyNum(keyNum) || !existKeyNum(keyNum)) {
				if(!validateKeyNum(keyNum)) {
					// Print a message when the format of key number is wrong.
					System.out.println("Please type a valid key number: ");
				}
				else if(!existKeyNum(keyNum)) {
					// Print a message when the key number is not exist in this system.
					System.out.println("This key has not been created. Please enter a used key number: ");
				}		
				// scanner the key number.
				keyNum = scanner.nextLine();
			}
			// keyAssignedFlag is the status of the entered key. Get the key object and key number, then get the status of the key object.
			keyAssignedFlag = getKeyByKeyNum(Integer.parseInt(keyNum)).getStatus();
			// check the status of the key object.
			if(keyAssignedFlag) {
				// If the key is assigned to another user, asking to enter another key number or exit this method.
				System.out.println("This key has been assigned to an user. Please select another key number or type \"back\" to choose another command:"); 
				keyNum = scanner.nextLine();
				// User decides to exit this method.
				if(keyNum.equals("back")) {
					return;
				};
			}
			else {
				// A key number which is valid and is existing in this system and has not been assigned to a user is found now.
				keyAssignedFlag = false;
			}
		}

		// Add key to a existing lock
		existUserObj.addKey(Integer.parseInt(keyNum));
		// Get the key object by key number.
		Key assignedKey = getKeyByKeyNum(Integer.parseInt(keyNum));
		// Since the key is assigned to an user, changed the status of this user to true(assigned to a user).
		assignedKey.changeStatus();
		updateUserList(existUserObj);
		updateKeyList(assignedKey);
		System.out.println("Key "+Integer.parseInt(keyNum)+" is added to User "+user);
	}
	
	/**
	 * The following method accepts a newUser.It's an updated user object.
	 * The old user object needs to be remove, then add the updated object to system's userList.
	 * @param newUser: an User Object. It's need to be updated in userList.
	 * @throws Exception: Throw exception if it's found.
	 */
	private static void updateUserList(User newUser) throws Exception{
		// Get username from newUser object.
		String username = newUser.getUserName();
		// Remove the old user.
		userList.remove(getUserByUsername(username));
		// Add the updated user.
		userList.add(newUser);
	}
	
	/**
	 * The following method accepts a username. It finds the user object by username. 
	 * @param username: the username entered.
	 * @return a user object whose name is the same as entered username.
	 * @throws Exception: throw exceptions if it's found.
	 */
	private static User getUserByUsername(String username) throws Exception{
		// userIndex is going to be each user in userList.
		User userIndex = null;
		// user is the return value whose name is the same as entered username.
		User user = null;
		// Create an iterator to loop through userList.
		Iterator<User> iter = userList.iterator(); 
		while(iter.hasNext()) {
			userIndex = iter.next();
			// Find the user.
			if(userIndex.getUserName().equals(username)) {
				user = userIndex;
				break;
			}
		}
		return user;
	}
	
	/**
	 * The following method accepts scanner as an argument. This method is to assigned a key to an existing lock.
	 * @param scanner: a scanner to scanner some information.
	 * @throws Exception: throw exceptions if it's found.
	 */
	private static void assignKeyToLock(Scanner scanner) throws Exception{
		// Get all key numbers in this system(keyList). If there is no key number found, printing a message and exit this method.
		if(getAllKeyNumbers().length() == 0) {
			System.out.println("There is no key created. Please choose command 3 to  add more keys");
			return;
		}
		// Printing all key numbers in this system(keyList)
		System.out.println("This is all used key ( "+getAllKeyNumbers()+")");
		// Ask user to enter a key number.
		System.out.println("Please choose a key number: ");
		// Get the key number.
		String keyNum = scanner.nextLine();
		// Create a flag to key. keyFlag will true until a key number is selected.
		boolean keyFlag = false;
		// Create a lock object.
		Lock existLockObj = null;
		String existLockNum = null;
		while(!keyFlag) {
			// Check the format of key number, and check whether this key number is exist in this system or not.
			while(!validateKeyNum(keyNum) || !existKeyNum(keyNum)) {
				if(!validateKeyNum(keyNum)) {
					System.out.println("Please type a valid key number: ");
				}
				else if(!existKeyNum(keyNum)) {
					System.out.println("This key has not been created. Please enter a used key number: ");
				}		
				// Scanner the next key number.
				keyNum = scanner.nextLine();
			}
			// Print a selected key number.
			System.out.println("(Reminder)Key number: "+keyNum+" is chosen.");
			// Print all lock numbers in lockList, and ask user to enter a lock number.
			System.out.println("Please choose a existing lock ( "+getAllLockNumbers()+")");
			// Get the lock number.
			existLockNum = scanner.nextLine();
			// Check the format of lock number, and check whether this lock number is exist in this system or not.
			while(!validateLockNum(existLockNum) || !existLockNum(existLockNum)) {
				System.out.println("Please choose a existing and valid lock number from ( "+getAllLockNumbers()+").");
				existLockNum = scanner.nextLine();
			}
			// Get a lock object by lock number.
			existLockObj = getLockByLockNum(Integer.parseInt(existLockNum));
			// Check whether the key has been assigned to this lock before. 
			if(keyMatchLock(Integer.parseInt(keyNum),existLockObj)) {
				System.out.println("Key "+keyNum+" has been assigned to lock "+existLockNum+". Please choose another lock or type \"back\" to choose another command:");
				existLockNum = scanner.nextLine();
				// User decides to exit this method.
				if(existLockNum.equals("back")) {
					return;
				}
			}
			else {
				// A key number which is valid and is existing in this system and has not been assigned to this lock is found now.
				keyFlag = true;
			}
		}
		// Get the lock object by lock number.
		existLockObj = getLockByLockNum(Integer.parseInt(existLockNum));
		// Assign key to a lock.
		existLockObj.addKey(Integer.parseInt(keyNum));
		// Update lockList.
		updateLockList(existLockObj);
		// Print success message.
		System.out.println("Key "+Integer.parseInt(keyNum)+" is added to lock "+existLockNum);
	}
	
	/**
	 * It returns a string of all lock numbers in this system(lockList).
	 * @return lockNumList is a string contains all lock number in lockList.
	 */
	private static String getAllLockNumbers() {
		// create a string to store all lock numbers later.
		String lockNumList = "";
		// loop through lockList
		for(Lock lock:lockList) {
			// get each lock's lock number.
			lockNumList += lock.getLockNum()+" ";
		}
		return lockNumList;
	}
	/**
	 * It returns a string of all key numbers in this system(keyList).
	 * @return keyNumList is a string contains all key number in keyList.
	 */
	private static String getAllKeyNumbers() {
		// create a string to store all key numbers later.
		String keyNumList = "";
		// loop through keyList
		for(Key key:keyList) {
			// get each key's key number.
			keyNumList += key.getKeyNumber()+" ";
		}
		return keyNumList;
	}
	
	/**
	 * It returns a string of all usernames in this system(userList).
	 * @return userNameList is a string contains all usernames in userList.
	 */
	private static String getAllUserNames() {
		// create a string to store all usernames later.
		String userNameList = "";
		// loop through userList
		for(User user:userList) {
			// get each user's username.
			userNameList += user.getUserName()+" ";
		}
		return userNameList;
	}
	
	/**
	 * The following method accepts a key and a user. Key is a integer, and user is a user object.
	 * This method is to check whether the key has been assigned to the user.
	 * @param key: the entered key number
	 * @param user: a user object
	 * @return keyMatchUser is a boolean. If key has been assigned to this user, it will be true.
	 */
	private static boolean keyMatchUser(int key, User user) {
		// keyMatchUser will be true, if user has been assigned to lock.
		boolean keyMatchUser = false;
		// Get user's keylist.
		LinkedList<Integer> keyList = user.getKeyList();
		// Check whether user's keyList contains entered key.
		if(keyList.contains(key)) {
			// If user's keylist contains entered key, it will return true.
			keyMatchUser = true;
			return keyMatchUser;
		}
		return keyMatchUser;
	}
	
	/**
	 * The following method accepts a key and a lock. key is a integer, and lock is a lock object.
	 * This methods is to check whether the key has been assigned to the lock.
	 * @param key: the entered key number
	 * @param lock: a lock object.
	 * @return keyMatchLock is a boolean. If key has been assigned to lock, it will be true. 
	 */
	private static boolean keyMatchLock(int key, Lock lock) {
		// keyMatchLock will be true, it key has been assigned to lock.
		boolean keyMatchLock = false;
		// Get lock's keyList.
		LinkedList<Integer> matchKeyList = lock.getKeyList();
		// Check whether lock's keyList contains entered key.
		if(matchKeyList.contains(key)) {
			// If lock's keylist contains entered key, it will return true.
			keyMatchLock = true;
			return keyMatchLock;
		}
		return keyMatchLock;
	}
	
	/**
	 * The following method accepts a scanner as an argument. 
	 * This method is to add a new key to an existing lock.
	 * @param scanner: is a scanner to scanner entered information.
	 * @throws Exception: throw exception if it's found.
	 */
	private static void createKeyToLock(Scanner scanner) throws Exception{
		// Display all key numbers in the system(keyList)
		System.out.println("This is all used key ( "+getAllKeyNumbers()+")");
		// Ask user to enter a key number.
		System.out.println("Please enter a new key number(between 1 and 200): ");
		// Get the entered key number.
		String newKeyNum = scanner.nextLine();
		// Check the format of key number, and check whether this key number is exist in this system or not.
		while(!validateKeyNum(newKeyNum) || existKeyNum(newKeyNum)) {
			if(!validateKeyNum(newKeyNum)) {
				System.out.println("Please type a valid key number: ");
			}
			else if(existKeyNum(newKeyNum)) {
				System.out.println("This key has been used. Please enter a new key number: ");
			}		
			// Get the next key number.
			newKeyNum = scanner.nextLine();
		}
		// Print selected key number.
		System.out.println("Key number "+newKeyNum+" is valid");
		// Print all lock number is this system and ask user to enter a lock number.
		System.out.println("Please choose a existing lock ( "+getAllLockNumbers()+")");
		// Get entered lock number.
		String existLockNum = scanner.nextLine();
		// Check the format of lock number, and check whether this lock number is exist in this system or not.
		while(!validateLockNum(existLockNum) || !existLockNum(existLockNum)) {
			// Ask user to enter anther lock number.
			System.out.println("Please choose a existing lock number from ( "+getAllLockNumbers()+")");
			existLockNum = scanner.nextLine();
		}
		// Get the lock object by lock number.
		Lock existLockObj = getLockByLockNum(Integer.parseInt(existLockNum));
		// Create a key object. It contains a key number, and a status.
		Key newKey = new Key(Integer.parseInt(newKeyNum),false);
		// Add the new key into the system(keyList)
		keyList.add(newKey);
		// Add a new key to an existing lock
		existLockObj.addKey(Integer.parseInt(newKeyNum));
		// Update the lockList. 
		updateLockList(existLockObj);
		// Print success message.
		System.out.println("Key "+Integer.parseInt(newKeyNum)+" is added to lock "+existLockNum);
	}
	
	/**
	 * The following method accepts a newLock. It's an updated lock object.
	 * The old lock object need to be remove from lockList, then add the updated lock object to system's keyList
	 * @param newLock: an lock object. It needs to be added into lockList.
	 * @throws Exception: throw exception if it's found.
	 */
	private static void updateLockList(Lock newLock) throws Exception{
		// Get lock number from newLock object.
		int lockNum = newLock.getLockNum();
		// Remove old lock object.
		lockList.remove(getLockByLockNum(lockNum));
		// Add the updated lock.
		lockList.add(newLock);
	}
	
	/**
	 * The following method accepts a newKey. It's an updated key object.
	 * The old key object need to be remove from useList, then add the updated key object to system's keyList
	 * @param newKey: an key object. It needs to be added into keyList.
	 * @throws Exception: throw exception if it's found.
	 */
	private static void updateKeyList(Key newKey) throws Exception{
		// Get key number from newKey object.
		int keyNum = newKey.getKeyNumber();
		// Remove old key object.
		keyList.remove(getKeyByKeyNum(keyNum));
		// Add the updated key.
		keyList.add(newKey);
	}

	
	/**
	 * The following method accepts one lockNum as argument. This method returns the lock object which is associated
	 * with this lock number.
	 * @param lockNum: the entered lock number.
	 * @return lock is an lock object. It contains a lock number and a list of key numbers.
	 * @throws Exception: throw exceptions if it's found.
	 */
	private static Lock getLockByLockNum(int lockNum) throws Exception{
		// Create a lock object. It will store each lock object of lockList(in the system) later.
		Lock lockIndex = null;
		// Create a lock object. It will store the lock object which matches entered lockNum;
		Lock lock = null;
		// Create an iterator on lockList.
		Iterator<Lock> iter = lockList.iterator(); 
		// Loop through lockList.
		while(iter.hasNext()) {
			// Get each lock object of lockList.
			lockIndex = iter.next();
			// Compare each lock number with entered lock number
			if(lockIndex.getLockNum() == lockNum) {
				// Find the matched lock object.
				lock = lockIndex;
				break;
			}
		}
		
		return lock;
	}
	/**
	 * The following method accepts one keyNum as argument. This method returns the key object which is associated
	 * with this key number.
	 * @param keyNum: the entered key number
	 * @return key is an key object. It contains a key number and a status.
	 * @throws Exception: throw exceptions if it's found.
	 */
	private static Key getKeyByKeyNum(int keyNum) throws Exception{
		// Create a key object. It will store each key object of keylist(in the system) later.
		Key keyIndex = null;
		// Create a key object. It will store the key object which matches entered keyNum.
		Key key = null;
		// Create an iterator on keyList.
		Iterator<Key> iter = keyList.iterator(); 
		// Loop through keyList
		while(iter.hasNext()) {
			// Get each key object of keyList.
			keyIndex = iter.next();
			// Compare each key number with entered keyNum.
			if(keyIndex.getKeyNumber() == keyNum) {
				// Find the matched key object. 
				key = keyIndex;
				break;
			}
		}		
		return key;
	}
	
	/**
	 * The following methods accepts a scanner as an argument. This methods is to create a user object, and an empty keylist will be assigned to it.
	 * The new user will be added into this system(userList)
	 * @param scanner: it will scanner entered information.
	 * @throws Exception: throw exceptions if it's found.
	 */
	private static void createUser(Scanner scanner) throws Exception{
		// Asking user to enter a valid username.
		System.out.println("Note: The username must comprise of lowercase alphabets only and can have one to eight letter(s).");
		System.out.println("Please add a username: ");
		// usr stores the entered username.
		String usr = scanner.nextLine();
		// Check for the correct format of username and check whether it is existing in the system(userList) or not. 
		while(!validateUserName(usr) || existUserName(usr)) {
			if(!validateUserName(usr)) {
				System.out.println("Please re-enter a valid username: ");
			}
			else {
				System.out.println("Sorry, this username has been used, please re-enter another one: ");
			}
			// scanner the next username.
			usr = scanner.nextLine();
		}
		// create an new user, and assigned a empty key number list to it.
		User user = new User(usr,new LinkedList<Integer>());
		// Add the new user object into this system(userList).
		userList.add(user);
		// Print a success message.
		System.out.println("User "+usr+" Created!");
	}
	/**
	 * The following methods accepts a scanner as an argument. This methods is to create a lock object,
	 * and It will also create a new key to assign it to this lock. new lock and new key both will be
	 * added to lockList and keyList
	 * @param scanner: it will scanner entered information.
	 * @throws Exception: throw exceptions if it's found.
	 */
	private static void createLock(Scanner scanner) throws Exception{
		// Ask user to enter a new lock number
		System.out.println("Note: The lock number must be an integer number between 1 and 100. 01 is the same as 1");
		System.out.println("Please add a lock number: ");
		// Store the entered lock number.
		String lockNum = scanner.nextLine();
		// Check for the correct format of lockNum and check whether it is existing in the system(lockList) or not. 
		while(!validateLockNum(lockNum) || existLockNum(lockNum)) {  
			if(!validateLockNum(lockNum)) {
				System.out.println("Please re-enter a valid lock number: ");
			}
			else {
				System.out.println("Sorry, this lock number has been used, please re-enter another one: ");
			}
			// Scanner the next lock number.
			lockNum = scanner.nextLine();
		}
		// Asking to enter a key number. 
		System.out.println("Note: The key number must be an integer number between 1 and 200.");
		System.out.println("Please add a key number: ");
		String keyNum = scanner.nextLine();
		// Check for the correct format of keyNum and check whether it is existing in the system(keyList) or not. 
		while(!validateKeyNum(keyNum) || existKeyNum(keyNum)) {
			if(!validateKeyNum(keyNum)) {
				System.out.println("Please re-enter a valid key number: ");
			}
			else {
				System.out.println("Sorry, this key number has been used, please re-enter another one: ");
			}
			// Scanner the next key number.
			keyNum = scanner.nextLine();
		}
		// Create an initial key list for this user. 
		LinkedList<Integer> initKeyList = new LinkedList<>();
		// The initial key list should contain a new key number.
		initKeyList.add(Integer.parseInt(keyNum));
		// Create an new lock object with lock number and a keylist assigned to this lock.
		Lock lock = new Lock(Integer.parseInt(lockNum),initKeyList);
		// Create an new key object.
		Key newKey = new Key(Integer.parseInt(keyNum),false);
		// Add new key object to keyList(in the system).
		keyList.add(newKey);
		// Add new lock object to lockList(in the system).
		lockList.add(lock);
		// Print success message.
		System.out.println("Lock: "+lockNum+" created with key: "+keyNum);
	}
	
	/**
	 * The following method accepts one keyNum. keyNum is a string. This method checks the correct format of 
	 * entered keyNum. The keyNum must be a string format of number between 1 and 200.
	 * @param keyNum: the entered key number.
	 * @return validKeyNum: it will be false if keyNum is not in proper format.
	 */
	private static boolean validateKeyNum(String keyNum) {
		// validKeyNum will be false if keyNum is not in proper format.
		boolean validKeyNum = true;
		// If keyNum is not a string format of number, Integer.parseInt will throw an exception.
		try{
			// key is the integer format of lockNum
			int key = Integer.parseInt( keyNum );    
			// The lock number needs to between 1 and 100.
			if(key>200 || key <=0) {
				validKeyNum = false;
				return validKeyNum;
			}
		}
		catch(Exception e)
		{   // When the keyNum is not in proper format, It will be catch. 
			validKeyNum = false;
			return validKeyNum;
		}
		return validKeyNum;
	}
	/**
	 * The following method accepts one keyNum. keyNum is a string. This method is to check whether the key num
	 * is existing in this system or not.
	 * @param keyNum: the entered key number.
	 * @return existKeyNum: it will be true if the key number is found in this system.
	 */
	private static boolean existKeyNum(String keyNum) {
		// existKeyNum will be true when the keyNum is found in this system.
		boolean existKeyNum = false;
		// Make sure the key number is in proper format.
		if(validateKeyNum(keyNum)) {
			// Key is the integer format of key number.
			int key = Integer.parseInt( keyNum ); 
			// Crate an iterator for keyList.
			Iterator<Key> iterator = keyList.iterator();
			// keyIndex will store each key object in keyList later.
			Key keyIndex = null;
			// keyIndexNum will store each key object's number of keyList later.
			int keyIndexNum = 0;
			// Loop through the keyList.
			while(iterator.hasNext()) {
				// Get each key object in keyList.
				keyIndex = iterator.next();
				// Get key number of each key object.
				keyIndexNum = keyIndex.getKeyNumber();
				// Compare keyIndexNum with entered key number.
				if(keyIndexNum == key) {
					// return true when we find the key num in keyList.
					existKeyNum = true;
					return existKeyNum;
				}
			}
		}
		return existKeyNum;
	}
		
	/**
	 * The following method accepts one lockNum. LockNum is a string. This method is to check whether the lock num
	 * is existing in this system or not.
	 * @param lockNum: the entered lock number.
	 * @return existLockNum: it will be true if the lock number is found in this system.
	 */
	private static boolean existLockNum(String lockNum) {
		// existingLocNum will be true when the lockNum is found in this system.
		boolean existLocNum = false;
		// Make sure the lock num is in proper format.
		if(validateLockNum(lockNum)) {
			// Get the integer format of lockNum.
			int loc = Integer.parseInt( lockNum );      
			// Create an iterator for lockList.
			Iterator<Lock> iterator = lockList.iterator();
			// Loop through lockList.
			while(iterator.hasNext()) {
				// Get each lock of lockList.
				Lock lock = iterator.next();
				// Compare lockNum with each lock's number in locklist.
				if(lock.getLockNum() == loc) {
					// return true when we find the lockNum in lockList.
					existLocNum = true;
					return existLocNum;
				}
			}
		}
		return existLocNum;
	}
		
	/**
	 * The following method accepts one lockNum. lockNum is a string. This method checks the correct format of 
	 * entered lockNum. The lockNum must be a string format of number between 1 and 100.
	 * @param lockNum: the entered lock number.
	 * @return
	 */
	private static boolean validateLockNum(String lockNum) {
		// validLockNum will be false if lockNum is not in proper format.
		boolean validLocNum = true;
		// If lockNum is not a string format of number, Integer.parseInt will throw an exception.
		try{
			// loc is the integer format of lockNum
			int loc = Integer.parseInt( lockNum );    
			// The lock number needs to between 1 and 100.
			if(loc>100 || loc <=0) {
				validLocNum = false;
				return validLocNum;
			}
		}
		catch(Exception e)
		{	// When the lockNum is not in proper format, It will be catch. 
			validLocNum = false;
			return validLocNum;
		}
		return validLocNum;
	}
	
	/**
	 * The following method accepts one usr. usr is a string type. This method will check whether this username
	 * is existing in this system or not.
	 * @param usr: the entered username.
	 * @return existNameFlag: It will be true, if entered username is existing in this sistey,
	 */
	private static boolean existUserName(String usr) {
		// existNameFlag will be false if usr is not existing in this system.
		boolean existNameFlag = false;
		// Create an iterator on userList. To check each user object in this system.
		Iterator<User> iterator = userList.iterator();
		// To store each user later.
		User user = null;
		// Keep looping until it hits the end of this list.
		while(iterator.hasNext()){
			// Get each user in userList.
			user = iterator.next();
			// Check whether this user's name is the same as usr.
			if(user.getUserName().equals(usr)) {
				existNameFlag = true;
				return existNameFlag;
			}
		}
		return existNameFlag;
	}
	
	/**
	 * The following method accepts one usr. usr is a string. This method checks the correct format of 
	 * entered username. The username must comprise of lowercase alphabets, and the length of username should between 1 and 8.
	 * @param usr: the entered username.
	 * @return nameFlag: nameFlag is a boolean type. If the format of usr is correct, it should be true.
	 */
	private static boolean validateUserName(String usr) {
		// nameFlag will be false if usr is not in proper format.
		boolean nameFlag = true;
		// make sure the length of username should between 1 and 8.
		if(usr.length() > 8 || usr.length()<1) {
			//throw new Exception;
			nameFlag = false;
		}
        // check for valid characters in username
        int i = 0;
        while (i < usr.length()) {
        		// Make sure the username is comprise of lowercase alphabets.
            if (usr.charAt(i) < 97 || usr.charAt(i) > 122) {
            		nameFlag = false;
            }
            i++;
        }
        return nameFlag;
	}
	/**
	 * The following method accepts one command. Command is a string. This method checks the correct format of entered 
	 * command. Command needs to be a string type of number between 1 and 9.
	 * @param command: the command that user enters. 
	 * @return commandFlag: commandFlag is a boolean type. If the command is valid, commandFlag is true.
	 */
	private static boolean validateCommand(String command) {
		// commandFlag will be false if command is not in proper format.
		boolean commandFlag = true;
		// Check whether the command is a string format of number between 1 and 9.
		if(command.length() != 1) {
			commandFlag = false;
		}else {
			// Make sure the command is a string format of number between 1 and 9.
			if(command.charAt(0) > 58 || command.charAt(0) <49 ) {
				commandFlag = false;
			}
		}
		return commandFlag;
	}
	/**
	 * Print all commands and commands' descriptions. 
	 * @param scanner: to scanner the command that user enters.
	 */
	private static void printCommands(Scanner scanner) {
		System.out.println("Please type a number from 1 to 9 to choose a command: ");
		System.out.println("1. Add a new user to the system. ");
		System.out.println("2. Add a new lock to the system. ");
		System.out.println("3. Add a new key to an existing lock. ");
		System.out.println("4. Assign a key to an existing lock. ");
		System.out.println("5. Assign a key to a user. ");
		System.out.println("6. Take away a key from a user. ");
		System.out.println("7. Display all keys. ");
		System.out.println("8. Display all locks. ");
		System.out.println("9. Display all the keys for a user. ");		
	}

}
