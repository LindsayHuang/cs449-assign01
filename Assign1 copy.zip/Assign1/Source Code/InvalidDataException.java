/*
 * This class represents an exception when invalid data is passed. It displays the
 * message from the caller.
 *
 * @author Wanqian Huang
 * created on Sep 12, 2018
 */
public class InvalidDataException extends Exception {

	/**
	 * The following is a constructor for this class. It accepts three Strings as parameters
	 * It prints an error message contains className, methodName and message information.
	 * @param className: the className where the exception occur.
	 * @param methodName: the methodName where the exception occur.
	 * @param message: the message describe this exception.
	 */
    public InvalidDataException (String className, 
                                 String methodName,
                                 String message) {
    		// Print the error message.
        System.out.println ("Invalid Data Exception thrown by class " + className + 
                            " in the method " + methodName + "\n" + 
                            message);
    }
}
