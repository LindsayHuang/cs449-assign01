/*
 * This class represents a key in the key system. Each key has a key number
 * and a status. Key number is an unique integer number, and status is a boolean. The key number
 * must be an integer number between 1 and 200. Status presents whether the key is assigned to 
 * a user or not. A key can only belong to a user at one time. If the key is assigned to a user, the status of the key should be true,
 * otherwise it should be false.
 * 
 * @author Wanqian(Lindsay) Huang
 * created on Sep 07, 2018
 */
public class Key {
	private int keyNumber;   
	private boolean status;
	
	/**
	 * The following is a constructor for this class (Key). It accepts one integer "keyNum"
	 * and a boolean "assigned" as parameters and assigns the values for the two state variables. 
	 * The construction throws an exception if the keyNumber of assigned is not in proper format
	 * or value as explained in the comment at the beginning of this class.
	 * @param keyNum: the key number to be assigned to the key
	 * @param assigned: the status to be assigned to the key
	 * @throws Exception: when keyNum or assigned is not in proper format or value throw a exception.
	 */
	public Key(int keyNum,boolean assigned) throws Exception {
		// Check for the correct keyNum for the lock. Lock number need to be unique and between 1 and 100.
		if(keyNum > 200 || keyNum<1) {
			throw new InvalidDataException ("Key",
	                "Key", "key number needs to be an integer number between 1 and 200");
		}
        // Check the valid status for the key.
        if(assigned) {
			throw new InvalidDataException ("Key",
	                "Key", "the status of key should be false when it's created. It may be assiged to an user later");
        }
        // Store the keyNumber and status as part of the key record.
        keyNumber = keyNum;
        status = assigned;
	}
	
	/**
	 * The following method allows to get the keyNumber of the key.
	 * @return the keyNumber of the key.
	 */
	public int getKeyNumber() {
		return keyNumber;
	}
	
	/**
	 * The following method allows a key to get the status of the key.
	 * @return the status(whether it's assigned to an user or not) of the key.
	 */
	public boolean getStatus() {
		return status;
	}
	
	/**
	 * The following method change the status of the key. 
	 */
	public void changeStatus() {
		//If the status of key was true, it will be changed to false.
		if(status) {
			status = false;
		}else {
			status = true;
		}
	}
}
